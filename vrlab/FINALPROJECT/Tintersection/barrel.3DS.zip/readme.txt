-- 3dvia.com   --

The zip file barrel.3DS.zip contains the following files :
- readme.txt
- barrel.3DS
- txtbar.jpg


-- Model information --

Model Name : barrel
Author : jero45
Publisher : jero45

You can view this model here :
http://www.3dvia.com/content/7505566B7D4F6173
More models about this author :
http://www.3dvia.com/jero45


-- Attached license --

A license is attached to the barrel model and all related media.
You must agree with this licence before using the enclosed media.

License : Attribution License 2.5
Detailed license : http://creativecommons.org/licenses/by/2.5/

The licenses used by 3dvia are based on Creative Commons Licenses.
More info: http://creativecommons.org/about/licenses/meet-the-licenses
